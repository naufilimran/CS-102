import java.util.Scanner;
import java.lang.Math;
import java.util.Arrays;
public class Hangmen{
  public static void main(String[] args){
    String[] animals = {"cat", "dog", "lion", "cow","ant","bee","bird","frog","giraffe","pigeon"};
    String random_animal = animals[(int)(Math.random()*10)];
    char[] dashes=new char[random_animal.length()];
    Scanner input = new Scanner(System.in);
    for (int i=0;i<random_animal.length();i++){
        dashes[i]='_';    
    }

    System.out.println(Arrays.toString(dashes));   
    int lives=6;
    int count=0;
    
    while(count != random_animal.length() && lives != 0){
      
      boolean guess=false;
      System.out.print("please enter a character: ");
      char user_input = input.next().charAt(0);
      
      for (int i=0;i<random_animal.length();i++){
 
          if(random_animal.charAt(i)==user_input){
              dashes[i]=user_input;
              count++;
              guess=true;
          }
    }
      
    if (guess==false){
          lives--;
          System.out.println("You have "+lives +" lives remaining");
          drawing(lives);
    } 
    
    System.out.println(dashes);
  }

  if (lives==0){
        System.out.println("You lost");
        System.out.println("The correct word was "+random_animal);
      }
  else{
        System.out.println("Congratulations you won, indeed the correct word was "+random_animal);
      }


}

 public static void drawing(int lives){
    if(lives == 1) {
       System.out.println("__________");
       System.out.println("|    |");
       System.out.println("|    O");
       for (int i=0;i<5;i++){
          System.out.println("|");

    }
}
    else if(lives == 2) {
       System.out.println("__________");
       System.out.println("|    |");
       System.out.println("|    O");
       System.out.println("|    |");
       for (int i=0;i<4;i++){
        System.out.println("|");

    }
  }
    else if(lives == 3) {
       System.out.println("__________");
       System.out.println("|    |");
       System.out.println("|    O");
       System.out.println("|   -|");
       for (int i=0;i<4;i++){
        System.out.println("|");

    }
  }
    else if(lives == 4) {
       System.out.println("__________");
       System.out.println("|    |");
       System.out.println("|    O");
       System.out.println("|   -|-");
       for (int i=0;i<4;i++){
            System.out.println("|");

    }
  }
    else if(lives == 5) {
       System.out.println("__________");
       System.out.println("|    |");
       System.out.println("|    O");
       System.out.println("|   -|-");
       System.out.println("|   /");
       for (int i=0;i<3;i++){
        System.out.println("|");

    }
  }
     else if (lives == 0){
      System.out.println("__________");
      for (int i=0;i< 5;i++){
          System.out.println("|");
      }
      System.out.println("The person vanished ");
    
  }
}

}  