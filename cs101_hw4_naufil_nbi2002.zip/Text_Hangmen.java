import java.util.Scanner;
import java.lang.Math;
import java.util.Arrays;
import java.io.*;
public class Text_Hangmen{
  public static void main(String[] args) throws Exception{
    String[] animals = new String[74];
    
    File sourceFile = null;

    Scanner file_input = null;
    
    int j=0;


    try { 
       sourceFile = new File("animals.txt");
       file_input = new Scanner(sourceFile);
    
   
      while (file_input.hasNext()) {

        // get a string (line) from the scanner input 
        String s1 = file_input.nextLine();


        // assign the string to an element of the array
        animals[j] = s1;
        
        j += 1;
      }
     
    }

    catch (Exception e){
        System.err.println("Error: " + e.getMessage());
        System.exit(0);// exit the program and no need to continue
    }

        finally{   
                file_input.close();   
        }

    String random_animal = animals[(int)(Math.random()*75)];
    
    char[] dashes=new char[random_animal.length()];
    
    Scanner input = new Scanner(System.in);
    
    for (int i=0;i<random_animal.length();i++){
        dashes[i]='_';    
    }

    System.out.println(Arrays.toString(dashes));   
    int lives=6;
    int count=0;
    
    while(count != random_animal.length() && lives != 0){
      
      boolean guess=false;
      System.out.print("please enter a character: ");
      char user_input = input.next().charAt(0);
      
      for (int i=0;i<random_animal.length();i++){
 
          if(random_animal.charAt(i)==user_input){
              dashes[i]=user_input;
              count++;
              guess=true;
          }
    }
      
    if (guess==false){
          lives--;
          System.out.println("You have "+lives +" lives remaining");
          drawing(lives);
    } 
    
    System.out.println(dashes);
  }

  if (lives==0){
        System.out.println("You lost");
        System.out.println("The correct word was "+random_animal);
      }
  else{
        System.out.println("Congratulations you won,indeed the correct word was "+random_animal);
      }


}

 public static void drawing(int lives){
    if(lives == 1) {
       System.out.println("__________");
       System.out.println("|    |");
       System.out.println("|    O");
       for (int i=0;i<5;i++){
          System.out.println("|");

    }
}
    else if(lives == 2) {
       System.out.println("__________");
       System.out.println("|    |");
       System.out.println("|    O");
       System.out.println("|    |");
       for (int i=0;i<4;i++){
        System.out.println("|");

    }
  }
    else if(lives == 3) {
       System.out.println("__________");
       System.out.println("|    |");
       System.out.println("|    O");
       System.out.println("|   -|");
       for (int i=0;i<4;i++){
        System.out.println("|");

    }
  }
    else if(lives == 4) {
       System.out.println("__________");
       System.out.println("|    |");
       System.out.println("|    O");
       System.out.println("|   -|-");
       for (int i=0;i<4;i++){
            System.out.println("|");

    }
  }
    else if(lives == 5) {
       System.out.println("__________");
       System.out.println("|    |");
       System.out.println("|    O");
       System.out.println("|   -|-");
       System.out.println("|   /");
       for (int i=0;i<3;i++){
        System.out.println("|");

    }
  }
     else if (lives == 0){
      System.out.println("__________");
      for (int i=0;i< 5;i++){
          System.out.println("|");
      }
      System.out.println("The person vanished ");
    
  }
}

} 