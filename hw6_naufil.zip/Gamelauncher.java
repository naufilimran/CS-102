package HW_6;
import java.util.Scanner;
public class Gamelauncher {
	public static void main(String[] args) {
		Board board_1 = new Board(10,'r','c');
boolean status = false;
		board_1.printBoard();
		Scanner in = new Scanner(System.in);
		String input;
		boolean game_end=false;
		int guess=0;
//		board1.generateRandom();
		String[] array = board_1.generateRandom();
		Game game = new Game(board_1, array, guess);
		Player player1 = new Player(board_1, array, guess);
		
		
//		while (!status){
			while(!status) {
				System.out.println("Enter coordinate to target");
				
				int row_input = 0 ;
				int col_no;
				int col_input;
				char col_error='-';
				
				input=in.nextLine();
				
				char[] arr = input.toCharArray();
				
				if (arr.length>2){
	 				String string_1 = Integer.toString(Character.getNumericValue(arr[1]));
	 				String string_2= Integer.toString(Character.getNumericValue(arr[2]));
	 				String string_final=string_1+string_2;
	 				int c = Integer.parseInt(string_final);
	 				row_input=c;
	 				col_error=arr[0];
	 				col_input=(int)arr[0];
				}else{
	 				row_input= Character.getNumericValue(arr[1]);
	 				col_error=arr[0];
	 				col_input=(int)arr[0];
				}
					
				//using this to check if input is out of errors or not
				if (col_error <'A' || col_error >'J' || row_input<0 || row_input >9){
	 				System.out.println("This position is off the bounds of the board! Try again.");
	 				continue;
				}

				col_no=col_input-65;
				//checking is user has already made a position at that move
				if(board_1.board[row_input][col_no] == '#' ) {
					System.out.println("you have already made a move at this position! Try again.");				
					continue;
				}
					
				//checking if the user does not enter the column number as an alphabet
				boolean character= Character.isLetter(col_error);
				if (character==false) {
					System.out.println("Not a valid input");
					continue;
				}

				//checking for inputs that are not within our range for inputs
				for(char characters: arr) {
					if (characters<48 && characters>57 && characters<65 && characters>74){
						System.out.println(" Not a valid input");
					continue;
					}
				}
				//breaking the loop and then calling 	
				if (row_input >=0 && row_input <=10 && col_no >=0 && col_no<=10){
//					game.isEnd(row_input,col_no,game_end,array);
					if(game.isEnd(row_input,col_no,game_end,array)) {
						status = true;
						break;
					}
					player1.update(row_input, array ,col_no);
					board_1.printBoard();
				}
				
			}
			

				
			
//		}
	}
}	
