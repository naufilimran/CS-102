package HW_6;
import java.util.Arrays;
public class Board {
	 //Initialize our board with dashes (empty positions)
	
    	int size;   
    	String [] array = new String[4];	
    	char [][] board;
		public Board(int size,char c1,char c2) {			
			this.size=size;
			this.board= new char[size][size];
			if( size > 0)
	    	{
		    	for(int r = 0; r < size; r++)
		    	{
		    		for(int c = 0; c < size; c++)
		    		{
		    			this.board[r][c] = '-';
		    		}
		    	}
		    
	    	}
		    else {
		    	this.board = null;
		    }
		}
		
		public void printBoard() {
			System.out.println("Battleship board");
			
			System.out.print(" ");
	
			for (char col = 'A'; col <= 'J'; col++) {
				System.out.print(" "+col);
			}
	
			System.out.println();
	
			//making the board and printing it out
			for(int i = 0; i < board.length; i++) {
			//The inner for loop prints out each row of the board
				System.out.print(i);
				for(int j = 0; j < board[i].length; j++) {
					System.out.print("|");
					System.out.print(board[i][j]);	
				}
			//This print statement makes a new line so that each row is on a separate line
				System.out.print("|");
				System.out.println();
			}
		}
			
		public String[] generateRandom() {
		for (int i = 0; i < 4; i++) {
			int random_no=(int)(Math.random()*10);
			int random_no_1=(int)(Math.random()*10);
			array[i]=random_no + "" + random_no_1;
			}
		return array;
		}
//}

}