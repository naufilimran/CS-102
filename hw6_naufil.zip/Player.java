package HW_6;

public class Player {
	private String[] array1 ;
	private int guess;
	private Board board;	
	boolean found = false;
	public Player(Board board_1, String [] random_array, int guess) {
		this.board=board_1;
		this.array1=random_array;
		this.guess=guess;
	}

	public int update(int row,String[] array, int col) {
		found = false;
		char[][] b1 = board.board;
		String num1;
		num1 = col+""+row;
		for (int i = 0 ; i< array1.length;i++) {
			Object element = array1[i];
            if (element.equals(num1)) {
            	found  = true;
            }
        }
		if(found == false) {
			b1[row][col]='#';
		}
		return guess;	
			
}
					
}
