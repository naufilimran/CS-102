package HW_6;

import java.util.Scanner;

public class Game {
	private String[] array1;
	private int guess;
	private Board board;
	boolean game_end = false;
	private String num;
	int count=0;
	public Game(Board board_1, String[] array2, int guess){
		this.board=board_1;
		this.guess=guess;
		this.array1 = array2;
		
	}
	
	public boolean isEnd(int row,int col,boolean game_end, String[] array) {
   		//checking for if the user gets the rows right
		char[][] b1 = board.board;
//			if(b1[row][col] == random_array[row][col] && b1[row+1][col] ==random_array[row+1][col] && b1[row+2][col]== random_array[row+2][col] && b1[row+3][col]== random_array[row+3][col] ) {
			num = col+""+row;
			for (int i = 0 ; i< array1.length;i++) {
				Object element = array1[i];
	            if (element.equals(num)) {
	            	b1[row][col]='X';
	            	count++;
	            	break;
	            }
	        }
			guess++;
			if (count==4) {
				System.out.println("Congratulations, you have won");
				System.out.println("It took you "+ guess+"guess");
				return true;
			}

			return false;
	
} 	
}


